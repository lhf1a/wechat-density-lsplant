SKIPUNZIP=0
chmod 755 "$MODPATH/service.sh" "$MODPATH/uninstall.sh"
