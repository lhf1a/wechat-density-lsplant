SKIPUNZIP=0
# Stay disabled at boot; operator may load at runtime.
touch "$MODPATH/disable"
